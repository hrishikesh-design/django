from django.shortcuts import render
import json
import pytz
from datetime import datetime
import urllib.request
# Create your views here.
def index(request):
    if request.method=="POST":
        city=request.POST['city']
        res = urllib.request.urlopen('http://api.openweathermap.org/data/2.5/weather?q='+city+'&appid=2b9ca96b8fff56239a6d65c60270f2fb').read()
        json_data=json.loads(res)  
        print(json_data) 
        data={
            "country":str(json_data['sys']['country']),
            "coordinate":"longitude"+str(json_data['coord']['lon'])+'  latitude:'+str(json_data['coord']['lat']),
            "weather":(json_data['weather'][0]['description']),
            "icon":(json_data['weather'][0]['icon']),
            "temp":str(round((json_data['main']['temp'])-273.15))+'°C',
            "pressure":str(json_data['main']['pressure']),
            "humidity":str(json_data['main']['humidity']),
            # "timezone":str(datetime.no(json_data['timezone']))
        }
    else:
        city=""
        data = {}
    return render(request,"index.html",{"city":city,"data":data})
