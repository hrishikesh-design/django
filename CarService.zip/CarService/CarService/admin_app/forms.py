from django import forms
from . models import *


class MechanicForm(forms.ModelForm):
    class Meta:
        model = Mechanic
        fields= "__all__"
class FloorManagerForm(forms.ModelForm):
    class Meta:
        model = FloorManager
        fields = "__all__"

class CleanerForm(forms.ModelForm):
    class Meta:
        model = Cleaner
        fields = "__all__"
        