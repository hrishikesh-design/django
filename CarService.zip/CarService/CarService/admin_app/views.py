from django.shortcuts import render,redirect
from app.models import *
# Create your views here.
from . forms import *
from django.contrib import messages
from django.http import HttpResponse,HttpResponseRedirect


def Admin_Home(request):
    return render(request,"admin.html")

def Add_Mechanic(request):
    if request.method=="POST":
        form = MechanicForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"New Mechanic Added.!")

            return redirect("Add_Mechanic_Done")
    else:
        form = MechanicForm()
    return render(request,"Mechanic.html",{"form":form})


def Add_Mechanic_Done(request):
    return render(request,"Add_Mechanic_Done.html")

def Read_Mechanic(request):
    read=Mechanic.objects.all()
    return render(request,"Read_Mechanic.html",{"read":read})

def Update_Mechanic(request,id):
    upd=Mechanic.objects.get(id=id)
    update = MechanicForm(request.POST or None,request.FILES or None,instance=upd)
    if update.is_valid():
        update.save()
        return redirect("Read_Mechanic")

    return render(request,"Update_Mechanic.html",{"update":update})

def Delete_Mechanic(request, id):  
    dele = Mechanic.objects.get(id=id)  
    dele.delete()  
    return redirect("Read_Mechanic") 

def Add_Floor_Manager(request):
    if request.method=="POST":
        form = FloorManagerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"New Floor Manager Added")
            return redirect("Add_Floor_Manager_Done")
    else:
        form = FloorManagerForm()
    return render(request,"Floor_Manager.html",{"form":form})

def Add_Floor_Manager_Done(request):
    return render(request,"Add_Floor_Manager_Done.html")


def Read_Floor_Manager(request):
    read=FloorManager.objects.all()
    return render(request,"Read_Floor_Manager.html",{"read":read})

def Update_Floor_Manager(request,id):
    upd=FloorManager.objects.get(id=id)
    update = FloorManagerForm(request.POST or None,request.FILES or None,instance=upd)
    if update.is_valid():
        update.save()
        return redirect("Read_Floor_Manager")

    return render(request,"Update_Floor_Manager.html",{"update":update})

def Delete_Floor_Manager(request, id):  
    dele = FloorManager.objects.get(id=id)  
    dele.delete()  
    return redirect("Read_Floor_Manager")  







def Add_Cleaner(request):
    if request.method=="POST":
        form = CleanerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"New Cleaner Added")
            return redirect("Add_Cleaner_Done")
    else:
        form = CleanerForm()
    return render(request,"Cleaner.html",{"form":form})

def Add_Cleaner_Done(request):
    return render(request,"Add_Cleaner_Done.html")

def Read_Cleaner(request):
    read=Cleaner.objects.all()
    return render(request,"Read_Cleaner.html",{"read":read})

def Update_Cleaner(request,id):
    upd=Cleaner.objects.get(id=id)
    update = CleanerForm(request.POST or None,request.FILES or None,instance=upd)
    if update.is_valid():
        update.save()
        return redirect("Read_Cleaner")

    return render(request,"Update_Cleaner.html",{"update":update})

def Delete_Cleaner(request, id):  
    dele = Cleaner.objects.get(id=id)  
    dele.delete()  
    return redirect("Read_Cleaner")  