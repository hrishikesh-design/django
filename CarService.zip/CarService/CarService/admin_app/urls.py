from django.contrib import admin
from django.urls import path
from django.conf import settings
from . import views


urlpatterns = [
    path("Admin_Home/",views.Admin_Home,name="Admin_Home"),
    path("Add_Mechanic",views.Add_Mechanic,name="Add_Mechanic"),
    path("Add_Mechanic_Done",views.Add_Mechanic_Done,name="Add_Mechanic_Done"),
    path("Add_Mechanic",views.Add_Mechanic,name="Add_Mechanic"),
    path("Add_Floor_Manager",views.Add_Floor_Manager,name="Add_Floor_Manager"),
    path("Add_Floor_Manager_Done",views.Add_Floor_Manager_Done,name="Add_Floor_Manager_Done"),
    path("Add_Cleaner",views.Add_Cleaner,name="Add_Cleaner"),
    path("Add_Cleaner_Done",views.Add_Cleaner_Done,name="Add_Cleaner_Done"),

    path("Read_Mechanic/",views.Read_Mechanic,name="Read_Mechanic"),
    path("Update_Mechanic/<int:id>",views.Update_Mechanic,name="Update_Mechanic"),
    path("Delete_Mechanic/<int:id>", views.Delete_Mechanic,name="Delete_Mechanic"), 
   
    path("Read_Floor_Manager/",views.Read_Floor_Manager,name="Read_Floor_Manager"),
    path("Update_Floor_Manager/<int:id>",views.Update_Floor_Manager,name="Update_Floor_Manager"),
    path("Delete_Floor_Manager/<int:id>", views.Delete_Floor_Manager,name="Delete_Floor_Manager"), 
    
    path("Read_Cleaner/",views.Read_Cleaner,name="Read_Cleaner"),
    path("Update_Cleaner/<int:id>",views.Update_Cleaner,name="Update_Cleaner"),
    path("Delete_Cleaner/<int:id>", views.Delete_Cleaner,name="Delete_Cleaner"), 

]