from django.db import models

# Create your models here.
class Service(models.Model):
    service = models.CharField(max_length=10)
    def __str__(self):
        return self.service

class Pickup(models.Model):
    Customer_Name = models.CharField(max_length=20)
    Customer_Phno = models.IntegerField()
    Car_No = models.CharField(max_length=10,default='')
    Car_Model = models.CharField(max_length=10,default='')
    Service_Type = models.ForeignKey(Service,on_delete = models.CASCADE,default='   ')
    Problem = models.CharField(max_length=100,default='')
    Image = models.ImageField()
    def __str__(self):
        return self.Customer_Name


class Appointment(models.Model):
    Customer_Name = models.CharField(max_length=20)
    Customer_Phno = models.IntegerField()
    Email = models.EmailField(default='')

    Car_No = models.CharField(max_length=10)
    Car_Model = models.CharField(max_length=10,default='')
    Date = models.DateField()
    Problem = models.CharField(max_length=100)
    Time = models.TimeField(auto_now=False, auto_now_add=False)

    def __str__(self):
        return self.Customer_Name


