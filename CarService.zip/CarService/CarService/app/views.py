from django.shortcuts import render,redirect

# Create your views here.
from . forms import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from . forms import Registration
from django.shortcuts import render
from CarService.settings import EMAIL_HOST_USER

from django.core.mail import send_mail


def Home(request):
    return render(request,"home.html")

def Request_Pickup(request):
    if request.method == "POST":
        form = PickupForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect("Pickup_Done")
    else:
        form = PickupForm()
    return render(request,"pickup.html",{"form":form})

def Pickup_Done(request):
    return render(request,"Pickup_Done.html")

def Read_Request_Pickup(request):
    read=Pickup.objects.all()
    return render(request,"Read_Request_Pickup.html",{"read":read})

def Request_Appointment(request):
    if request.method ==  "POST":
        form = AppointmentForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect("Appointment_Done")
    else:
        form = AppointmentForm()
    return render(request,"Appointment.html",{"form":form})

def Appointment_Done(request):
    return render(request,"Appointment_Done.html")

def Read_Appointment(request):
    read=Appointment.objects.all()
    return render(request,"Read_Appointment_Request.html",{"read":read})

def subscribe(request):
    sub = forms.AppointmentForm()
    if request.method == 'POST':
        sub = forms.AppointmentForm(request.POST)
        subject = 'Welcome '
        message = ' Your appointment confirmed'
        recepient = str(sub['Email'].value())
        send_mail(subject, 
            message, EMAIL_HOST_USER, [recepient], fail_silently = False)
        return render(request, 'Appointment_Done.html', {'recepient': recepient})
    
    else:
        form = AppointmentForm()
        return render(request,"Appointment.html",{"form":form})