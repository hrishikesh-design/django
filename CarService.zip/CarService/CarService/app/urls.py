from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path("",views.Home,name="Home"),
    path("Request_Pickup/",views.Request_Pickup,name="Request_Pickup"),
    path("Pickup_Done",views.Pickup_Done,name="Pickup_Done"),
    path("Request_Appointment",views.Request_Appointment,name="Request_Appointment"),
    path("Appointment_Done",views.Appointment_Done,name="Appointment_Done"),
    path("Read_Appointment/",views.Read_Appointment,name="Read_Appointment"),
    
    path("Read_Request_Pickup/",views.Read_Request_Pickup,name="Read_Request_Pickup"),

]

urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
